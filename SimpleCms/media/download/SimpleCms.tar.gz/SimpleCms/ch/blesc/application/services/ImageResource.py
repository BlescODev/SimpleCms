from flask_restful import Resource

class ImageResource(Resource):

    def __init__(self):
        pass
    
    def get(self, route):
        return 