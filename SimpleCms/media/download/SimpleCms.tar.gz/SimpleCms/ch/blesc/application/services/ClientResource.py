from flask_restful import Resource

class ClientResource(Resource):

    def __init__(self, **kwargs):
        self.app = kwargs['app']
        
    def get(self):
        return self.app.send_static_file('client/html/index.html')