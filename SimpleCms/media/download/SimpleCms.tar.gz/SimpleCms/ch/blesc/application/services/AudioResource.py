from flask_restful import Resource

class AudioResource(Resource):

    def __init__(self, **kwargs):
        self.pageRepository = kwargs['pageRepository']
        
    def get(self, route):
        return self.pageRepository.get(route)