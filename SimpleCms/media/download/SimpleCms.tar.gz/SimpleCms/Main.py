from flask import Flask
from flask_restful import Api
from ch.blesc.application.services.ClientResource import ClientResource
from ch.blesc.application.services.PageResource import PageResource
from ch.blesc.application.services.HtmlResource import HtmlResource
from ch.blesc.application.services.JavaScriptResource import JavaScriptResource
from ch.blesc.application.services.ImageResource import ImageResource
from ch.blesc.application.services.VideoResource import VideoResource
from ch.blesc.application.services.AudioResource import AudioResource
from ch.blesc.application.services.DownloadResource import DownloadResource

if __name__ == '__main__':
    app = Flask(__name__, static_folder='')
    api = Api(app)
    
    api.add_resource(ClientResource, '/',
            resource_class_kwargs={'app': app})
    api.add_resource(PageResource, '/page/<path:route>')
    
    api.add_resource(ImageResource, '/img/<path:route>')
    api.add_resource(VideoResource, '/video/<path:route>')
    api.add_resource(AudioResource, '/audio/<path:route>')
    api.add_resource(DownloadResource, '/download/<path:route>')
    
    api.add_resource(JavaScriptResource, '/js/<path:route>')
    api.add_resource(HtmlResource, '/html/<path:route>')
    
    
    app.run("0.0.0.0", 8080, True)